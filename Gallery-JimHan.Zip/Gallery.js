const HTTP_PORT = process.env.PORT || 3000;
const express = require("express");
const exphbs = require("express-handlebars");
const readline = require("linebyline");
const path = require("path");
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: false}));
app.use("/images", express.static(path.join(__dirname, "/public/images")));

app.engine(".hbs", exphbs.engine({
  extname: ".hbs",
  defaultLayout: false,
  layoutsDir: path.join(__dirname, "/views")
}));

app.set('view engine', '.hbs');

const rl = readline("./images.txt");
var image = [];
rl.on("line", (line, lineCount, byteCount) => {
  image.push(path.parse(line).name);
})

.on("error", (err) => {
  console.error(err);
});

app.get("/", function(req, res){
  
  res.render('gallery', {image});
});

app.post("/", function(req, res){
  var selected = req.body.rdoImage;
  res.render('gallery', {selected, image});
})


const server = app.listen(HTTP_PORT, () => {
  console.log(`Listening on port ${HTTP_PORT}`);
});